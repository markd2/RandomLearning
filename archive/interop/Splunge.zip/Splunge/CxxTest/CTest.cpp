#include "CTest.hpp"

int cxxFunction(int n) {
    return n;
}
