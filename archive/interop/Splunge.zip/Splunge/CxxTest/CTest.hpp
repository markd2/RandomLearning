#ifndef CTest_hpp
#define CTest_hpp

int cxxFunction(int n);

#endif

