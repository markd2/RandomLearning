//
//  HappyFunTime.h
//  HappyFunTime
//
//  Created by Mark Dalrymple on 10/18/23.
//

#import <Foundation/Foundation.h>

//! Project version number for HappyFunTime.
FOUNDATION_EXPORT double HappyFunTimeVersionNumber;

//! Project version string for HappyFunTime.
FOUNDATION_EXPORT const unsigned char HappyFunTimeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HappyFunTime/PublicHeader.h>

#import <HappyFunTime/HappyFun.hpp>

